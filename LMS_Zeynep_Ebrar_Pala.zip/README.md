# 🎓 AI-Powered LMS: Akıllı Eğitim Yönetim Sistemi

Bu proje, yapay zeka teknolojilerini (LLM) modern web mimarisiyle birleştirerek, herhangi bir konuyu saniyeler içinde tam kapsamlı bir müfretada ve ders içeriklerine dönüştüren uçtan uca bir **Öğrenme Yönetim Sistemi (LMS)** çözümüdür.

**Geliştiren:** **ZEYNEP EBRAR PALA**

---

## 🌟 Proje Özeti
- **🧠 Çoklu Model Desteği**: Google **Gemini** ve **Groq** API entegrasyonu.
- **🔐 Kullanıcı Yönetimi**: SHA256 tabanlı güvenli giriş ve kayıt sistemi.
- **📄 PDF Raporu**: Oluşturulan kursları Türkçe karakter desteğiyle PDF olarak indirme.
- **☁️ Canlı Yayın Hazır**: Streamlit Cloud için optimize edilmiş tek dosya (`streamlit_app.py`) yapısı.

## 🚀 Canlıya Alım (Streamlit Cloud Deployment)
Bu projeyi Streamlit Cloud üzerinde yayınlamak için şu adımları izleyin:
1.  Bu repository'yi GitHub hesabınıza yükleyin.
2.  [Streamlit Cloud](https://share.streamlit.io/) sitesine gidin ve GitHub ile giriş yapın.
3.  **"New app"** butonuna basın.
4.  Repository olarak `lms-yapayzeka-130` seçin.
5.  **Main file path** kısmına `streamlit_app.py` yazın.
6.  **"Deploy!"** butonuna basın.

---

## 🛠️ Kurulum (Yerel Çalıştırma)

### 1. Bağımlılıkları Yükleyin
```bash
pip install -r requirements.txt
```

### 2. Uygulamayı Başlatın
```bash
streamlit run streamlit_app.py
```

---

## 📂 Dosya Yapısı
- `streamlit_app.py`: Ana uygulama doyası (Backend + Frontend birleşik).
- `requirements.txt`: Gerekli Python kütüphaneleri.
- `.gitignore`: Gereksiz dosyaların GitHub'a yüklenmesini engeller.
- `README.md`: Proje dökümantasyonu.

## 📝 Lisans ve Notlar
Bu proje CV geliştirme ve yapay zeka ürünleştirme vizyonuyla hazırlanmıştır. Geliştirici referansı olarak **ZEYNEP EBRAR PALA** isminin korunması rica olunur.
